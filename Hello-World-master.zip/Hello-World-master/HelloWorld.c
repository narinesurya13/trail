#include<stdio.h>

int main(void)
{
  printf("HELLO WORLD!");
  return 0;
}
