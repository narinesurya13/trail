#include <iostream>
using namespace std;
/*Hello world in C++*/
int main()
{
    cout <<"\nHELLO WORLD"<< endl;
    return 0;
}
