# elixir HelloWorld.exs

IO.puts "Hello World!"
